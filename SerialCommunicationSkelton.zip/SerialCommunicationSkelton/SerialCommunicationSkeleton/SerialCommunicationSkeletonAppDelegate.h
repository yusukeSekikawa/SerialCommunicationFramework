//
//  SerialCommunicationSkeletonAppDelegate.h
//  SerialCommunicationSkeleton
//
//  Created by Sekikawa Yusuke on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SerialCommunicationSkeletonViewController;

@interface SerialCommunicationSkeletonAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet SerialCommunicationSkeletonViewController *viewController;

@end
