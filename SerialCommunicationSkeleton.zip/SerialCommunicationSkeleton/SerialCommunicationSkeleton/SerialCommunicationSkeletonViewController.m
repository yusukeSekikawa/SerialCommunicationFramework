/*
 * SerialCommunication.framework for iOS
 * sample code
 * SerialCommunicationSkeletonViewController.c
 *
 * Copyright (c) Yusuke Sekikawa, 11/06/02
 * All rights reserved.
 * 
 * BSD License
 *
 * Redistribution and use in source and binary forms, with or without modification, are 
 * permitted provided that the following conditions are met:
 * - Redistributions of source code must retain the above copyright notice, this list of
 *  conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright notice, this list
 *  of conditions and the following disclaimer in the documentation and/or other materia
 * ls provided with the distribution.
 * - Neither the name of the "Yuichi Yoshida" nor the names of its contributors may be u
 * sed to endorse or promote products derived from this software without specific prior 
 * written permission.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY E
 * XPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES O
 * F MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SH
 * ALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENT
 * AL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROC
 * UREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS I
 * NTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRI
 * CT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF T
 * HE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#define  LED3_RED       2
#define  LED3_GREEN     4
#define  LED3_BLUE      3

#define  LED2_RED       5
#define  LED2_GREEN     7
#define  LED2_BLUE      6

#define  LED1_RED       8
#define  LED1_GREEN     10
#define  LED1_BLUE      9

#define  SERVO1         11
#define  SERVO2         12
#define  SERVO3         13

#define  RELAY1         14
#define  RELAY2         15

#define  LIGHT_SENSOR   16
#define  TEMP_SENSOR    17

#define  BUTTON1        18
#define  BUTTON2        19
#define  BUTTON3        20

#import "SerialCommunicationSkeletonViewController.h"

@implementation SerialCommunicationSkeletonViewController

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];

    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    _serialCommunication = [[SerialCommunication alloc] init];
    if(_serialCommunication){
        _serialCommunication.delegate=self;
    }else{
        [self.view setBackgroundColor:[UIColor lightGrayColor]];
    }
    relay1IsOn=NO;
    relay2IsOn=NO;
    [super viewDidLoad];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
-(IBAction)relay1:(id)sender{
    uint8_t msg[4];
    
    msg[0]=0xff;
    msg[1]=0x03;
    msg[2]=0x00;
    relay1IsOn=!relay1IsOn;
    if(relay1IsOn){
        [relay1 setTitle:@"on" forState:UIControlStateNormal];
        msg[3]=0x01;
    }else{
        [relay1 setTitle:@"off" forState:UIControlStateNormal];
        msg[3]=0x00;
    }
    int dataToSend;
    memcpy(&dataToSend, msg, sizeof(msg));
    int byteSent=[_serialCommunication sendSerialData:dataToSend];
    NSLog(@"relya1 %d byte send",byteSent);

}
-(IBAction)relay2:(id)sender{
    uint8_t msg[4];
    
    msg[0]=0xff;
    msg[1]=0x03;
    msg[2]=0x01;
    relay2IsOn=!relay2IsOn;
    if(relay2IsOn){
        [relay2 setTitle:@"on" forState:UIControlStateNormal];
        msg[3]=0x01;
    }else{
        [relay2 setTitle:@"off" forState:UIControlStateNormal];
        msg[3]=0x00;
    }
    int dataToSend;
    memcpy(&dataToSend, msg, sizeof(msg));
    int byteSent=[_serialCommunication sendSerialData:dataToSend];
    NSLog(@"relya2 %d byte send{%d,%d,%d,%d}",byteSent,msg[0],msg[1],msg[2],msg[3]);

}
-(IBAction)sliderValChanged:(id)sender{
    uint8_t msg[4];
    
    msg[0]=0xff;
    msg[1]=0x02;
    
    if(sender==LED1R || sender==LED1G || sender==LED1B||
       sender==LED2R || sender==LED2G || sender==LED2B||
       sender==LED3R || sender==LED3G || sender==LED3B){
        if(sender==LED1R)
            msg[2]=0x00;
        else if(sender==LED1G)
            msg[2]=0x01;
        else if(sender==LED1B)
            msg[2]=0x02;
        else if(sender==LED2R)
            msg[2]=0x03;
        else if(sender==LED2G)
            msg[2]=0x04;
        else if(sender==LED2B)
            msg[2]=0x05;
        else if(sender==LED3R)
            msg[2]=0x06;
        else if(sender==LED3G)
            msg[2]=0x07;
        else if(sender==LED3B)
            msg[2]=0x08;
    }else if(sender ==SERVO01||sender ==SERVO02||sender ==SERVO03){
        if(sender==SERVO01)
            msg[2]=0x10;
        else if(sender==SERVO02)
            msg[2]=0x11;
        else if(sender==SERVO03)
            msg[2]=0x12; 
    }
    msg[3]=((UISlider*)sender).value;
    int dataToSend;
    memcpy(&dataToSend, msg, sizeof(msg));
    int byteSent=[_serialCommunication sendSerialData:dataToSend];
    //NSLog(@"sliderValChanged %d byte send{%d,%d,%d,%d}",byteSent,msg[0],msg[1],msg[2],msg[3]);
}


-(void)serialDataRecieved:(int)data{
    uint8_t msg[4];
    memcpy(msg, &data, sizeof(msg));
    if(msg[1]==0x1){
        //buttons
        switch (msg[2]) {
            case 0x0:
                [button1 setBackgroundColor:(msg[3]==0 ? [UIColor darkGrayColor]:[UIColor redColor])];
                break;
            case 0x1:
                [button2 setBackgroundColor:(msg[3]==0 ? [UIColor darkGrayColor]:[UIColor redColor])];
                break;
            case 0x2:
                [button3 setBackgroundColor:(msg[3]==0 ? [UIColor darkGrayColor]:[UIColor redColor])];
                break;
            case 0x4:
                [buttonJoy setImage:(msg[3]==0 ? [UIImage imageNamed:@"joy_n"]:[UIImage imageNamed:@"joy_s"])];
                break;
            default:
                break;
        }
    }else if(msg[1]==0x4){
        //temperature
        int tempVal=msg[3]|(msg[2]<<8);
        temp.text=[NSString stringWithFormat:@"%d ℃",tempVal];
    }else if(msg[1]==0x5){
        //light
        int lightal=msg[3]|(msg[2]<<8);
        light.text=[NSString stringWithFormat:@"%d ‰",lightal];
    }else if(msg[1]==0x6){
        //light
        char x=msg[2];
        char y=msg[3];
        int xx=x+160;
        int yy=y+240;
        buttonJoy.center=CGPointMake(xx, yy);
    }else{
        NSLog(@"Unknown msg:{%d,%d,%d,%d}",msg[0],msg[1],msg[2],msg[3]); 
    } 
}
-(void)serialAlert:(NSString*)msg{
    NSLog(@"message:%@",msg);
}
@end
